# Bitcoin-Key-Compression-Tool
Get R, S and Z values from Raw Bitcoin Transaction

https://youtu.be/LIyssI5ZUDk

https://2coin.org/getRSZfromRawTX.html

Bitcoin Key Compression Tool
https://iancoleman.io/bitcoin-key-compression


-----------------------------------------
python2.7 !

pip install requests

pip install urllib2

python R-Scaner.py

-------------------------------------------
install ubuntu 18.04 LTS or windows 10 app

install python 2.7 + package

sudo apt install python

sudo apt install python-pip

pip install bitcoin

pip install ecdsa

pip install utils

pip install base58

git clone https://github.com/160Bit/Bitcoin-Key-Compression-Tool.git

cd Bitcoin-Key-Compression-Tool

python RawTX_RSZ.py

