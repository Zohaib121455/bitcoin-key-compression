# Bitcoin-Key-Compression-Tool
Get R, S and Z values from Raw Bitcoin Transaction

requirements:

Python2.7

modules-colorama,bitcoin,ecdsa,utils,base58

for Ubuntu 20.04 wget https://bootstrap.pypa.io/pip/2.7/get-pip.py 

sudo python2 get-pip.py pip install colorama

https://youtu.be/LIyssI5ZUDk

https://2xoin.com/getRSZfromRawTX/

Bitcoin Key Compression Tool https://iancoleman.io/bitcoin-key-compression

-----------------------------------------

